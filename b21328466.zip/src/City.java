import java.util.HashMap;
import java.util.List;

/**
 * The City class has three attributes:
 * index, name and routes which contain
 * the routes to the nearby cities and
 * which transportation type can be used.*/
public class City {
    private int index;
    private String name;
    private HashMap<City, List<Character>> routes;

    /**
     * Class constructor.
     */
    City(String name, int num) {
        this.name = name;
        index = num;
        routes = new HashMap<>();
    }

    public int getIndex() {
        return index;
    }

    public String getName() {
        return name;
    }

    public HashMap<City, List<Character>> getRoutes() {
        return routes;
    }
}
